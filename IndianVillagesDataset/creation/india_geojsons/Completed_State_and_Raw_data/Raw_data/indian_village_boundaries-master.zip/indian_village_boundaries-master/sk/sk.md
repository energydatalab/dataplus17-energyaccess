## Sikkim

* Total Villages and Towns: 
* Census State code: 
* Short Name: SK

### Credits

### Supporting Documents
- [SK - Bhuvan Panchayat - Digital Empowerment of Society for Panchayat level Planning and Governance](http://www.bhuvan-panchayat.nrsc.gov.in/#SISDP)
- [SK - Administrative Atlas Sikkim -Census Of India 2011](http://www.censusindia.gov.in/2011census/maps/atlas/11Preface%20and%20acknoladgement.pdf)

### Status
- [x] Intial Map complete 
- [ ] Needs Taluk/District/Village boundary verification
- [ ] 2011 village coding needs to be done
- [ ] Need 2001 Village coding creation
- [ ] Need to remove unwanted attributes
- [ ] Need to rename the attribute to reflect the attribute


