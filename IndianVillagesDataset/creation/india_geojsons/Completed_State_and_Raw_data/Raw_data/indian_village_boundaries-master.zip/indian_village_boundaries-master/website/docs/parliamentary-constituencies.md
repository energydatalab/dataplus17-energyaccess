<script>
window.location.href="http://projects.datameet.org/maps/parliamentary-constituencies/";
</script>