description: A list of tutorials that are useful to work with Indian village boundary maps

# Tutorials 
- [Converting GeoJSON into Shapefile](https://archive.org/details/geojson_to_shapefile)
- [Exploring GeoJSON and renaming fields](https://archive.org/details/exploring_geojson_and_renaming_fields)
- [Mapping GeoJSON files on GitHub](https://help.github.com/articles/mapping-geojson-files-on-github/) 