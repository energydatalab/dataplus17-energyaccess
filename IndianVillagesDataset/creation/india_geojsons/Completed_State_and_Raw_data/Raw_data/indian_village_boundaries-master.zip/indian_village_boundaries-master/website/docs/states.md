<script>
window.location.href="http://projects.datameet.org/maps/states";
</script>