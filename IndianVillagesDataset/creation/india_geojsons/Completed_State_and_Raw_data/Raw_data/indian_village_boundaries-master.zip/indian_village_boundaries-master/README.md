## Indian Village Boundaries
 
 - Please visit our [projects website for details](http://projects.datameet.org/indian_village_boundaries/).
 - Visit [DataMeet email group](https://groups.google.com/group/datameet) for discussion
 - License [ODBl](http://opendatacommons.org/licenses/odbl/)
 - Bound by [DataMeet Community Code of Conduct](http://datameet.org/wiki/guidelines:datameet-community-code-of-conduct)
 